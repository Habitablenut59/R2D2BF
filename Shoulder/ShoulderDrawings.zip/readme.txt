Shoulder is built in the following order from the leg outwards

ShoulderShim
ShoulderLayerBig
ShoulderLayerSmall
ShoulderLayerBig
ShoulderLayerSmall
ShoulderLayerBig
ShoulderLayerSmall
ShoulderLayerBig

Each layer is.125 inches thick.

